﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceClients" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServiceClients.svc o ServiceClients.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServiceClients : IServiceClients
    {
        //Heredamos las propiedades de la clase DBConnection
        internal class ClientsDB : DBConnection
        {
            internal bool Connected()
            {
                try
                {
                    using (Connection)
                    {
                        Connection.Open();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }

            internal string SearchClients(string condition = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchClients1";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Condition", condition);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }
            internal string SearchClient(int Id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchClient";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", Id);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }

            internal string InsertClient(string name, string lastName, string phoneNumber = "", string email = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "InsertClient";
                    command.CommandType = CommandType.StoredProcedure;

                    name = char.ToUpper(name[0]) + name.ToLower().Substring(1);
                    lastName = char.ToUpper(lastName[0]) + lastName.ToLower().Substring(1);

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    if (phoneNumber != "")
                    {
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    }
                    if (email != "")
                    {
                        command.Parameters.AddWithValue("@Email", email.ToLower());
                    }

                    // Agregar los parámetros al procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el cliente no se ha ingresado: {ex.Message}";
                }
            }
            internal string ModifyProduct(string id, string name, string lastName, string phoneNumber = "", string email = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "UpdateClient";
                    command.CommandType = CommandType.StoredProcedure;

                    name = char.ToUpper(name[0]) + name.ToLower().Substring(1);
                    lastName = char.ToUpper(lastName[0]) + lastName.ToLower().Substring(1);

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    if (phoneNumber != "" && phoneNumber != "N/A")
                    {
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    }
                    if (email != "" && email != "N/A")
                    {
                        command.Parameters.AddWithValue("@Email", email.ToLower());
                    }

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el cliente no se ha modificado: {ex.Message}";
                }
            }
            internal string DeleteClient(string id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "DeleteClient";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Id", int.Parse(id));

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el cliente no se ha borrado: {ex.Message}";
                }
            }
        }


        public bool Connected()
        {
            ClientsDB prodb = new ClientsDB();
            return prodb.Connected();
        }
        public string GetClients(string condition = "")
        {
            ClientsDB prodb = new ClientsDB();
            return prodb.SearchClients(condition);
        }
        public string GetClient(int id)
        {
            ClientsDB prodb = new ClientsDB();
            return prodb.SearchClient(id);
        }

        public string NewClient(string name, string lastName, string phone, string email)
        {
            ClientsDB prodb = new ClientsDB();
            return prodb.InsertClient(name, lastName, phone, email);
        }

        public string ModifyClient(string id, string name, string lastName, string phone, string email)
        {
            ClientsDB prodb = new ClientsDB();
            return prodb.ModifyProduct(id, name, lastName, phone, email);
        }

        public string DeleteClient(string id)
        {
            ClientsDB prodb = new ClientsDB();
            return prodb.DeleteClient(id);
        }
    }
}
