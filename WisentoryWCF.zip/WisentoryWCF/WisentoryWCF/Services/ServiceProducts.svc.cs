﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.DynamicData.ModelProviders;
using System.Web.UI.WebControls;
using System.Collections;
using System.Xml.Linq;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceProducts" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServiceProducts.svc o ServiceProducts.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServiceProducts : IServiceProducts    {
        //Heredamos las propiedades de la clase DBConnection
        internal class ProductsDB : DBConnection
        {
            internal bool Connected()
            {
                try
                {
                    using (Connection)
                    {
                        Connection.Open();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }

            internal string SearchProducts(string condition = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchProducts1";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Condition", condition);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }
            internal string SearchProduct(int Id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchProduct";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", Id);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }

            internal string InsertProduct(string name = "", string description = "", string vat = "", string buyprice = "", string sellprice = "", string stock = "", string supplierid = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "InsertProduct";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Description", description);
                    if (vat == "Sí")
                    {
                        command.Parameters.AddWithValue("@VAT", "Y");
                    }
                    if (vat == "No")
                    {
                        command.Parameters.AddWithValue("@VAT", "N");
                    }
                    command.Parameters.AddWithValue("@BuyPrice", double.Parse(buyprice));
                    command.Parameters.AddWithValue("@SellPrice", double.Parse(sellprice));
                    command.Parameters.AddWithValue("@Stock", int.Parse(stock));
                    command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierid));

                    // Agregar los parámetros al procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el producto no se ha ingresado: {ex.Message}";
                }
            }
            internal string ModifyProduct(string id, string name, string description, string vat, string buyprice, string sellprice, string stock, string supplierid)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "UpdateProduct";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", int.Parse(id));
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Description", description);
                    if (vat == "Sí")
                    {
                        command.Parameters.AddWithValue("@VAT", "Y");
                    }
                    if (vat == "No")
                    {
                        command.Parameters.AddWithValue("@VAT", "N");
                    }
                    command.Parameters.AddWithValue("@BuyPrice", double.Parse(buyprice));
                    command.Parameters.AddWithValue("@SellPrice", double.Parse(sellprice));
                    command.Parameters.AddWithValue("@Stock", int.Parse(stock));
                    command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierid));
                    
                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el producto no se ha modificado: {ex.Message}";
                }
            }
            internal string DeleteProduct(string id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "DeleteProduct";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Id", int.Parse(id));

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el producto no se ha borrado: {ex.Message}";
                }
            }

        }

        public bool Connected()
        {
            ProductsDB prodb = new ProductsDB();
            return prodb.Connected();
        }
        public string GetProducts(string condition="")
        {
            ProductsDB prodb = new ProductsDB();
            return prodb.SearchProducts(condition);
        }
        public string GetProduct(int id)
        {
            ProductsDB prodb = new ProductsDB();
            return prodb.SearchProduct(id);
        }

        public string NewProduct(string name = "", string description = "", string vat = "", string buyprice = "", string sellprice = "", string stock = "", string supplierid = "")
        {
            ProductsDB prodb = new ProductsDB();
            return prodb.InsertProduct(name, description, vat, buyprice, sellprice, stock, supplierid);
        }

        public string ModifyProduct(string id, string name = "", string description = "", string vat = "", string buyprice = "", string sellprice = "", string stock = "", string supplierid = "")
        {
            ProductsDB prodb = new ProductsDB();
            return prodb.ModifyProduct(id, name, description, vat, buyprice, sellprice, stock, supplierid);
        }

        public string DeleteProduct(string id)
        {
            ProductsDB prodb = new ProductsDB();
            return prodb.DeleteProduct(id);
        }




    }
}
