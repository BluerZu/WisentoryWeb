﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceOrderDetails" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServiceOrderDetails.svc o ServiceOrderDetails.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServiceOrderDetails : IServiceOrderDetails
    {
        internal class OrderDetailDB : DBConnection
        {
            internal bool Connected()
            {
                try
                {
                    using (Connection)
                    {
                        Connection.Open();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }

            internal string SearchOrderDetails(int id, string condition = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchOrderDetail";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@OrderId", id);
                    command.Parameters.AddWithValue("@Condition", condition);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }
            internal string SearchOrderDetail(int id, string productid)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchOrderDetail";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@OrderId", id);
                    command.Parameters.AddWithValue("@Condition", productid);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }

            internal string InsertOrderDetail(int id, string productid, string amount)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "InsertOrderDetail";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@OrderId", id);
                    command.Parameters.AddWithValue("@ProductId", int.Parse(productid));
                    command.Parameters.AddWithValue("@Amount", int.Parse(amount));

                    // Agregar los parámetros al procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el detalle del pedido no se ha ingresado: {ex.Message}";
                }
            }
            internal string ModifyOrderDetail(int id, string detailid, string productid, string amount)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "UpdateOrderDetail";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@OrderId", id);
                    command.Parameters.AddWithValue("@DetailId", int.Parse(detailid));
                    command.Parameters.AddWithValue("@ProductId", int.Parse(productid));
                    command.Parameters.AddWithValue("@Amount", int.Parse(amount));


                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el detalle del pedido no se ha modificado: {ex.Message}";
                }
            }
            internal string DeleteOrderDetail(int id, string productid)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "DeleteOrderDetail";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@OrderId", id);
                    command.Parameters.AddWithValue("@ProductId", int.Parse(productid));

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el detalle del pedido no se ha borrado: {ex.Message}";
                }
            }

        }

        public bool Connected()
        {
            OrderDetailDB prodb = new OrderDetailDB();
            return prodb.Connected();
        }
        public string GetOrderDetails(int id, string condition = "")
        {
            OrderDetailDB prodb = new OrderDetailDB();
            return prodb.SearchOrderDetails(id, condition);
        }
        public string GetOrderDetail(int id, string productid)
        {
            OrderDetailDB prodb = new OrderDetailDB();
            return prodb.SearchOrderDetail(id, productid);
        }

        public string NewOrderDetail(int id, string productid, string amount)
        {
            OrderDetailDB prodb = new OrderDetailDB();
            return prodb.InsertOrderDetail(id, productid, amount);
        }

        public string ModifyOrderDetail(int id, string detailid, string productid, string amount)
        {
            OrderDetailDB prodb = new OrderDetailDB();
            return prodb.ModifyOrderDetail(id, detailid, productid, amount);
        }

        public string DeleteOrderDetail(int id, string productid)
        {
            OrderDetailDB prodb = new OrderDetailDB();
            return prodb.DeleteOrderDetail(id, productid);
        }
    }
}
