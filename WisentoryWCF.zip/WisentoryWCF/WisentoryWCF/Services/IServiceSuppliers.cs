﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceSuppliers" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceSuppliers
    {
        [OperationContract]
        bool Connected();

        [OperationContract]
        string GetSuppliers(string condition);

        [OperationContract]
        string GetSupplier(int id);

        [OperationContract]
        string NewSupplier(string name, string email, string number, string address);

        [OperationContract]
        string ModifySupplier(string id, string name, string email, string number, string address);

        [OperationContract]
        string DeleteSupplier(string id);
    }
}
