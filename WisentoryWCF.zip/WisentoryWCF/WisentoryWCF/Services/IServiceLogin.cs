﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceLogin" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceLogin
    {
        [OperationContract]
        bool Connected();

        [OperationContract]
        bool ValidUser(string user, string password);
    }
}
