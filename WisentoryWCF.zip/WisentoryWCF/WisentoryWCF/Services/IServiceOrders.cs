﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceOrders" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceOrders
    {
        [OperationContract]
        bool Connected();

        [OperationContract]
        string GetOrders(string condition);

        [OperationContract]
        string GetOrder(int id);
        [OperationContract]
        string NewOrder(string supplierid, string date, string status);

        [OperationContract]
        string ModifyOrder(string id, string supplierid, string date, string status);

        [OperationContract]
        string DeleteOrder(string id); 
    }
}
