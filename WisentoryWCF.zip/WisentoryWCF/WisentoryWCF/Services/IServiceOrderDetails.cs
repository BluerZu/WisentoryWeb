﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceOrderDetails" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceOrderDetails
    {
        [OperationContract]
        bool Connected();

        [OperationContract]
        string GetOrderDetails(int id, string condition);

        [OperationContract]
        string GetOrderDetail(int id, string productid);

        [OperationContract]
        string NewOrderDetail(int id, string productid, string amount);

        [OperationContract]
        string ModifyOrderDetail(int id, string detailid, string productid, string amount);

        [OperationContract]
        string DeleteOrderDetail(int id, string productid);
    }
}
