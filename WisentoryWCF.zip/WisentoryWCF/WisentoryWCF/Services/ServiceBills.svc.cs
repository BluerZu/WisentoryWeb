﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceBills" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServiceBills.svc o ServiceBills.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServiceBills : IServiceBills
    {
        //Heredamos las propiedades de la clase DBConnection
        internal class BillsDB : DBConnection
        {
            internal bool Connected()
            {
                try
                {
                    using (Connection)
                    {
                        Connection.Open();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }

            internal string SearchBills(string condition = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchBills1";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Condition", condition);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }

            internal string SearchBill(int Id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchBill";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", Id);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }

            internal string InsertBill(string clientid, string date)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "InsertBill";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@IdCliente", int.Parse(clientid));
                    command.Parameters.AddWithValue("@Fecha", DateTime.Parse(date));

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, la factura no se ha ingresado: {ex.Message}";
                }
            }
            internal string ModifyBill(string id, string clientid, string date)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "UpdateBill";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@Clientid", int.Parse(clientid));
                    command.Parameters.AddWithValue("@Date", DateTime.Parse(date));

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, la factura no se ha modificado: {ex.Message}";
                }
            }
            internal string DeleteBill(string id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "DeleteBill";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Id", id);

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, la factura no se ha borrado: {ex.Message}";
                }
            }
        }


        public bool Connected()
        {
            BillsDB prodb = new BillsDB();
            return prodb.Connected();
        }
        public string GetBills(string condition = "")
        {
            BillsDB prodb = new BillsDB();
            return prodb.SearchBills(condition);
        }
        public string GetBill(int id)
        {
            BillsDB prodb = new BillsDB();
            return prodb.SearchBill(id);
        }
        public string NewBill(string clientid, string date)
        {
            BillsDB prodb = new BillsDB();
            return prodb.InsertBill(clientid, date);
        }
        public string ModifyBill(string id, string clientid, string date)
        {
            BillsDB prodb = new BillsDB();
            return prodb.ModifyBill(id, clientid, date);
        }
        public string DeleteBill(string id)
        {
            BillsDB prodb = new BillsDB();
            return prodb.DeleteBill(id);
        }


    }
}
