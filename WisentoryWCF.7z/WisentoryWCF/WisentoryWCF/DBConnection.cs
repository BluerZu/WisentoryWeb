﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace WisentoryWCF
{
    internal class DBConnection
    {
        //Lee la cadena de conexión establecida en Web.config
        static string strconexion = WebConfigurationManager.ConnectionStrings["WisentoryDB"].ConnectionString;
        //Se define una variable pública Conexion que será utilizada por los objetos ADO.NET para manipular datos de la base
        public SqlConnection Connection = new SqlConnection(strconexion);
    }
}