﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceOrders" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServiceOrders.svc o ServiceOrders.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServiceOrders : IServiceOrders
    {
        //Heredamos las propiedades de la clase DBConnection
        internal class OrderDB : DBConnection
        {
            internal bool Connected()
            {
                try
                {
                    using (Connection)
                    {
                        Connection.Open();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }

            internal string SearchOrders(string condition = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchOrders1";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Condition", condition);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }
            internal string SearchOrder(int Id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchOrder";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", Id);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }

            internal string InsertOrder(string supplierId, string date, string status)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "InsertOrder";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Date", DateTime.Parse(date));
                    command.Parameters.AddWithValue("@Status", status);
                    command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierId));

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el pedido no se ha ingresado: {ex.Message}";
                }
            }
            internal string ModifyOrder(string id, string supplierId, string date, string status)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "UpdateOrder";
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@OrderId", id);
                    command.Parameters.AddWithValue("@SupplierId", int.Parse(supplierId));
                    command.Parameters.AddWithValue("@Date", DateTime.Parse(date));
                    command.Parameters.AddWithValue("@Status", status);

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el pedido no se ha modificado: {ex.Message}";
                }
            }
            internal string DeleteOrder(string id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "DeleteOrder";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Id", id);

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el pedido no se ha borrado: {ex.Message}";
                }
            }

        }


        public bool Connected()
        {
            OrderDB prodb = new OrderDB();
            return prodb.Connected();
        }
        public string GetOrders(string condition = "")
        {
            OrderDB prodb = new OrderDB();
            return prodb.SearchOrders(condition);
        }
        public string GetOrder(int id)
        {
            OrderDB prodb = new OrderDB();
            return prodb.SearchOrder(id);
        }
        public string NewOrder(string clientid, string date, string status)
        {
            OrderDB prodb = new OrderDB();
            return prodb.InsertOrder(clientid, date, status);
        }
        public string ModifyOrder(string id, string clientid, string date, string status)
        {
            OrderDB prodb = new OrderDB();
            return prodb.ModifyOrder(id, clientid, date, status);
        }
        public string DeleteOrder(string id)
        {
            OrderDB prodb = new OrderDB();
            return prodb.DeleteOrder(id);
        }
    }
}
