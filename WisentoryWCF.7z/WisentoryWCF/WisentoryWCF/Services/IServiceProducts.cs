﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Diagnostics;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceProducts" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceProducts
    {
        [OperationContract]
        bool Connected();

        [OperationContract]
        string GetProducts(string condition);

        [OperationContract]
        string GetProduct(int id);

        [OperationContract]
        string NewProduct(string name, string description, string vat, string buyprice, string sellprice, string stock, string supplierid);

        [OperationContract]
        string ModifyProduct(string id, string name, string description, string vat, string buyprice, string sellprice, string stock, string supplierid);

        [OperationContract]
        string DeleteProduct(string id);
    }

}
