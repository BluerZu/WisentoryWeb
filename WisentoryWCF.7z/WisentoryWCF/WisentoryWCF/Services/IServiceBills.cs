﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceBills" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceBills
    {
        [OperationContract]
        bool Connected();

        [OperationContract]
        string GetBills(string condition);

        [OperationContract]
        string GetBill(int id);
        [OperationContract]
        string NewBill(string clientid, string date);

        [OperationContract]
        string ModifyBill(string id, string clientid, string date);

        [OperationContract]
        string DeleteBill(string id);
    }
}
