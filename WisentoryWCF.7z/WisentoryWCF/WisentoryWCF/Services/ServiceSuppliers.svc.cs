﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using static WisentoryWCF.Services.ServiceClients;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceSuppliers" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServiceSuppliers.svc o ServiceSuppliers.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServiceSuppliers : IServiceSuppliers
    {
        internal class BillsDB : DBConnection
        {
            internal bool Connected()
            {
                try
                {
                    using (Connection)
                    {
                        Connection.Open();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }

            internal string SearchSuppliers(string condition = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchSuppliers1";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Condition", condition);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }
            internal string SearchSupplier(int Id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    //Utilizamos la clase Connection del padre DBConnection para la conexión con la base de datos
                    command.Connection = Connection;
                    command.CommandText = "SearchSupplier";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", Id);
                    Connection.Open();
                    SqlDataAdapter adaptador = new SqlDataAdapter(command);

                    DataSet dataSet = new DataSet();
                    adaptador.Fill(dataSet);
                    Connection.Close();

                    return dataSet.GetXml();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error: {ex.Message}";
                }
            }

            internal string InsertSupplier(string name, string email, string phoneNumber = "", string address = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "InsertSupplier";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Email", email);
                    if (phoneNumber != "")
                    {
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    }
                    if (address != "")
                    {
                        command.Parameters.AddWithValue("@Address", address);
                    }

                    // Agregar los parámetros al procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (Exception ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el proveedor no se ha ingresado: {ex.Message}";
                }
            }
            internal string ModifySupplier(string id, string name, string email, string phoneNumber = "", string address = "")
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "UpdateSupplier";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Email", email);
                    if (phoneNumber != "")
                    {
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    }
                    if (address != "")
                    {
                        command.Parameters.AddWithValue("@Address", address);
                    }

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";
                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el proveedor no se ha modificado: {ex.Message}";
                }
            }
            internal string DeleteSupplier(string id)
            {
                try
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "DeleteSupplier";
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@Id", int.Parse(id));

                    // Ejecutar el procedimiento almacenado
                    Connection.Open();
                    command.ExecuteNonQuery();
                    Connection.Close();

                    return "Ok";

                }
                catch (SqlException ex)
                {
                    // Manejar la excepción, registrarla o notificar al usuario según sea necesario
                    return $"Error, el proveedor no se ha borrado: {ex.Message}";
                }
            }
        }

        public bool Connected()
        {
            BillsDB prodb = new BillsDB();
            return prodb.Connected();
        }
        public string GetSuppliers(string condition = "")
        {
            BillsDB prodb = new BillsDB();
            return prodb.SearchSuppliers(condition);
        }
        public string GetSupplier(int id)
        {
            BillsDB prodb = new BillsDB();
            return prodb.SearchSupplier(id);
        }

        public string NewSupplier(string name, string email, string number, string address)
        {
            BillsDB prodb = new BillsDB();
            return prodb.InsertSupplier(name, email, number, address);
        }

        public string ModifySupplier(string id, string name, string email, string number, string address)
        {
            BillsDB prodb = new BillsDB();
            return prodb.ModifySupplier(id, name, email, number, address);
        }

        public string DeleteSupplier(string id)
        {
            BillsDB prodb = new BillsDB();
            return prodb.DeleteSupplier(id);
        }
    }
}
