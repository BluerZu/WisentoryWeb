﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using static WisentoryWCF.Services.ServiceProducts;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceLogin" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServiceLogin.svc o ServiceLogin.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServiceLogin : IServiceLogin
    {
        internal class UsersDB : DBConnection
        {
            internal bool Connected()
            {
                try
                {
                    using (Connection)
                    {
                        Connection.Open();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return false;
                }
            }

            internal bool ValidUser(string user, string password)
            {
                try
                {
                    string pattern = "WisentoryPattern";
                    SqlCommand command = new SqlCommand();
                    command.Connection = Connection;
                    command.CommandText = "ValidUser";
                    command.CommandType = CommandType.StoredProcedure;
                    // Agregar los parámetros al procedimiento almacenado
                    command.Parameters.AddWithValue("@User", user);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Pattern", pattern);

                    Connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        Connection.Close();
                        return true;
                    }
                    Connection.Close();
                    return false;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    return false;
                }
            }

        }
        public bool Connected()
        {
            UsersDB prodb = new UsersDB();
            return prodb.Connected();
        }
        public bool ValidUser(string user, string password)
        {
            UsersDB prodb = new UsersDB();
            return prodb.ValidUser(user, password);
        }
    }
}
