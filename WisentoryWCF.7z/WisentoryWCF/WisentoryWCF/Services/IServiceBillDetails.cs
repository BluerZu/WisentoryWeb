﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WisentoryWCF.Services
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceBillDetails" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceBillDetails
    {
        [OperationContract]
        bool Connected();

        [OperationContract]
        string GetBillDetails(int id, string condition);

        [OperationContract]
        string GetBillDetail(int id, string productid);

        [OperationContract]
        string NewBillDetail(int id, string productid, string amount);

        [OperationContract]
        string ModifyBillDetail(int id, string detailid, string productid, string amount);

        [OperationContract]
        string DeleteBillDetail(int id, string productid);
    }
}
